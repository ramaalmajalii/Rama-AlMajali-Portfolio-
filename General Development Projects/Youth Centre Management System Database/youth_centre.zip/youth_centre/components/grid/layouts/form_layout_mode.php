<?php

class FormLayoutMode
{
    const HORIZONTAL = 'horizontal';
    const VERTICAL = 'vertical';
}

class FormTabsStyle
{
    const TABS = 'tabs';
    const JUSTIFIED_TABS = 'justified-tabs';
    const PILLS = 'pills';
    const JUSTIFIED_PILLS = 'justified-pills';
    const STACKED_PILLS = 'stacked-pills';
}
