<?php

class FilterGroupOperator
{
    const OPERATOR_AND = 'AND';
    const OPERATOR_OR  = 'OR';
    const OPERATOR_NONE = 'NONE';
}